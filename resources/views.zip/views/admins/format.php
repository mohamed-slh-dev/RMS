@extends('layouts.admin')



{{-- section --}}
@section('content')



{{-- breadcrubms --}}



{{-- end breadcrubms --}}





{{-- content --}}




{{-- end content --}}









{{-- modals --}}



{{-- end modals --}}




@endsection
{{-- end section --}}