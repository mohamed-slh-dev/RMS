@extends('layouts.customer')




{{-- contents --}}
@section('content')

<div class="mdk-drawer-layout js-mdk-drawer-layout" data-push data-responsive-width="992px">
    <div class="mdk-drawer-layout__content page-content">

        <!-- Header -->

        <div class="container-fluid bg-white py-3"
            style="box-shadow:0px 0px 3px 0px lightgrey; position:fixed; z-index: 1000; bottom:0px; max-width: 100%;">

            <div class="row m-navbar-row">

                <!-- Navbar button -->
                <div class="col">
                    <a href="{{ route('customer.home') }}" class="btn btn-outline-primary w-100"><i class="fa fa-home"></i></a>
                </div>

                <!-- Navbar button -->
                <div class="col">
                    <a href="{{ route('customer.chat') }}" class="btn btn-outline-primary w-100"><i class="fa fa-comment-dots"></i></a>
                </div>

                <!-- Navbar button -->
                <div class="col">
                    <a href="{{ route('customer.store') }}" class="btn btn-outline-primary w-100"><i class="fa fa-store-alt"></i></a>
                </div>

                <!-- Navbar button -->
                <!-- <div class="col-2">
                        <a href="ad.html" class="btn btn-outline-primary w-100"><i class="fa fa-ad"></i></a>
                    </div> -->


                <!-- Navbar button -->
                <div class="col">
                    <a href="{{ route('customer.plan') }}" class="btn btn-outline-primary w-100"><i class="fa fa-calendar-alt"></i></a>
                </div>

                <!-- Navbar button -->
                <div class="col">
                    <a href="{{ route('customer.profile') }}" class="btn btn-primary w-100"><i class="fa fa-user"></i></a>
                </div>


            </div>
            {{-- end menu --}}









        </div>
        <!-- // END Header -->


        <!-- breadcrubms -->
        <div class="border-bottom-2 mt-3 position-relative z-1 mb-5">
            <div class="container-fluid">

                <div class="row align-items-center general-info-row align-items-center" style="margin-top:0px;">


                    <!-- general info -->
                    <div class="col-6 mt-4 mb-3">
                        <h6 class="mb-0 font-size-16">Edit Info</h6>
                    </div>

                    <div class="col-6 mt-4 text-right mb-3">
                        <a href="{{ route('customer.profile') }}" class="btn btn-white py-1"><i
                                class="fa fa-chevron-circle-left mr-2"></i>Back</a>
                    </div>


                    <div class="col-12">

                        <div class="row py-4 edit-profile-row"
                            style="border-radius:5px; box-shadow:0px 0px 3px 0px lightgrey">
                            <div class="col-6 mb-3">
                                <input type="text" name="" id="" placeholder="First Name" value="Idress"
                                    class="form-control">
                            </div>

                            <div class="col-6 mb-3">
                                <input type="text" name="" id="" placeholder="Last Name" value="Abdulrahman"
                                    class="form-control">
                            </div>

                            <div class="col-12 mb-3">
                                <input type="text" name="" id="" placeholder="Phone" value="971 23 231 333"
                                    class="form-control">
                            </div>


                            <div class="col-12 mb-3">
                                <input type="text" name="" id="" placeholder="Email" value="username@demo.com"
                                    class="form-control">
                            </div>


                            <div class="col-6 mb-3">
                                <input type="text" name="" id="" placeholder="Weight" value="65" class="form-control">
                            </div>


                            <div class="col-6 mb-3">
                                <input type="text" name="" id="" placeholder="Height" value="5.4" class="form-control">
                            </div>



                            <div class="col-12">
                                <hr>
                            </div>

                            <div class="col-12 mb-3">
                                <input type="text" name="" id="" placeholder="Address"
                                    value="Al Abar St. 121 near the gas-station" class="form-control">
                            </div>


                            <div class="col-6 mb-3">
                                <input type="text" name="" id="" placeholder="Block No." value="Block 28"
                                    class="form-control">
                            </div>


                            <div class="col-6 mb-3">
                                <input type="text" name="" id="" placeholder="Flat No." value="Flat 88LKD3"
                                    class="form-control">
                            </div>








                            <div class="col-12 mb-3">
                                <select name="" id="" class="form-control custom-select">
                                    <optgroup label="City" style="background-color: lightgrey; color:grey">
                                        <option value="">Sharjah</option>
                                        <option value="">Dubai</option>
                                    </optgroup>
                                </select>
                            </div>


                            <div class="col-12 mb-4">
                                <select name="" id="" class="form-control custom-select">
                                    <optgroup label="District" style="background-color: lightgrey; color:grey">
                                        <option value="">Al Abar</option>
                                        <option value="">Sharjah</option>
                                    </optgroup>
                                </select>
                            </div>



                            <div class="col-12 text-center mb-4">
                                <button class="btn btn-success px-4">
                                    Update
                                </button>
                            </div>






                        </div>

                    </div>
                    <!-- end general info -->




                </div>
                <!-- end row -->

            </div>
        </div>
        <!-- breadcrubms end -->



    </div>
    <!-- // END drawer-layout__content -->




    <!-- drawrer menu was here -->

    <!-- drawrer menu end -->



</div>
<!-- // END drawer-layout -->


@endsection






{{-- scripts --}}
@section('scripts')

<!-- package plan js (custom added) -->
<script src="{{ asset('assets/customer/js/package-plan.js') }}"></script>


<!-- package plan js (custom added) -->
<script src="{{ asset('assets/customer/js/customer-mobile.js') }}"></script>


@endsection




{{-- modals --}}
@section('modals')


@endsection