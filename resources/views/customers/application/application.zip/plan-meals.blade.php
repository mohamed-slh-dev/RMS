@extends('layouts.customer')




<!-- careful - copy when moving to laravel -->
<style>
    /* ---- my plan */
    .select2-selection {
        height: 120px !important;
        overflow: auto !important;
    }
</style>




{{-- content --}}
@section('content')


<!-- layout -->
<div class="mdk-drawer-layout js-mdk-drawer-layout" data-push data-responsive-width="992px">
    <div class="mdk-drawer-layout__content page-content">

        <!-- Header -->

        <div class="container-fluid bg-white py-3"
            style="box-shadow:0px 0px 3px 0px lightgrey; position:fixed; z-index: 1000; bottom:0px; max-width: 100%;">

            <div class="row m-navbar-row">

                <!-- Navbar button -->
                <div class="col">
                    <a href="{{ route('customer.home') }}" class="btn btn-outline-primary w-100"><i class="fa fa-home"></i></a>
                </div>

                <!-- Navbar button -->
                <div class="col">
                    <a href="{{ route('customer.chat') }}" class="btn btn-outline-primary w-100"><i class="fa fa-comment-dots"></i></a>
                </div>

                <!-- Navbar button -->
                <div class="col">
                    <a href="{{ route('customer.store') }}" class="btn btn-outline-primary w-100"><i class="fa fa-store-alt"></i></a>
                </div>

                <!-- Navbar button -->
                <!-- <div class="col-2">
                        <a href="ad.html" class="btn btn-outline-primary w-100"><i class="fa fa-ad"></i></a>
                    </div> -->


                <!-- Navbar button -->
                <div class="col">
                    <a href="{{ route('customer.plan') }}" class="btn btn-primary w-100"><i class="fa fa-calendar-alt"></i></a>
                </div>

                <!-- Navbar button -->
                <div class="col">
                    <a href="{{ route('customer.profile') }}" class="btn btn-outline-primary w-100"><i class="fa fa-user"></i></a>
                </div>


            </div>
            {{-- end menu --}}









        </div>
        <!-- // END Header -->


        <!-- breadcrubms -->
        <div class="border-bottom-2 mt-3 position-relative z-1">
            <div class="container-fluid">

                <div class="row align-items-center" style="margin-top:0px;">


                    <div class="col-12 text-center mb-1">
                        <img src="{{ asset('assets/customer/images/logo/RESTAURANT.png') }}" alt=""
                            style="width:100%; height:60px; object-fit: contain;">
                    </div>




                    <!-- meal info -->
                    <div class="col-12 text-center pt-3">
                        <h6 class="m-meal-heading mb-0">
                            <a data-toggle="modal" data-target=".package-info"></a>
                            Lean Package Meals
                        </h6>

                        <p class="mb-0 " style="font-size:14px;">20 Oct 2021</p>
                    </div>






                    <div class="col-12">

                        
                    </div>


                    <!-- carousal of meals -->

                    <!-- 1-breakfast -->
                    <div id="carousal-breakfast-col" class="form-group col-sm-12 mt-4 pos-relative">

                        <h6 class="mb-1">Breakfast</h6>


                        <!-- scroll right and left buttons -->
                        <div class="carousal-buttons-wrapper">

                            <!-- scroll left button -->
                            <button id="horizontal-carousal-button-left-1"
                                class="carousal-scroll-button-left btn btn-primary d-none">
                                <i class="fa fa-chevron-left"></i>
                            </button>

                            <!-- scroll right button -->
                            <button id="horizontal-carousal-button-right-1"
                                class="carousal-scroll-button-right btn btn-primary d-none">
                                <i class="fa fa-chevron-right"></i>
                            </button>

                        </div>

                        <!-- carousal -->
                        <div id="horizontal-carousal-1" class="custom-horizontal-carousal" tabindex=0
                            style="overflow-x: auto;">



                            <!-- card  -->
                            <label for="meal-breakfast-1" id="meal-breakfast-label-1" class="card-group-row__col carousal-cols meal-breakfast-labels">

                           
                                <input type="checkbox" class="meal-breakfast" name="meal-breakfast[]" id="meal-breakfast-1" value="packageMeal->id">

                                {{-- id of package_meal and meal_type_id --}}
                                <input type="hidden" name="breakfast-package-meal[]" value="packageMeal->id">
                                <input type="hidden" name="breakfast-package-meal-type[]" value="packageMeal->meal_type_id">


                                <div
                                    class="card card-group-row__card text-center o-hidden card--raised custom-schedule-cards ">

                                    <div class="card-body d-flex flex-column">
                                        <div class=" mb-16pt">


                                            <span
                                                class="w-64 h-64 icon-holder icon-holder--outline-accent rounded-circle d-inline-flex mb-16pt mt-3">
                                                <img width="90" height="90" src="{{ asset('assets/customer/images/stories/spicy.png') }}">
                                            </span>
                                            <h4 class="mb-8pt carousal-card-heading">Custome Meal
                                            </h4>
                                            <h6 class="mb-0 text-warning"> Breakfast </h6>
                                            <hr class="mt-2">
                                            <h5>Ingredients</h5>

                                            <div style="display: block ruby;">
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Pumpkin<br>
                                                        <span class="badge badge-notifications badge-secondary">(700)
                                                            Gram</span>
                                                    </p>
                                                </div>
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Potato<br>
                                                        <span class="badge badge-notifications badge-secondary">(200)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Gralic<br>
                                                        <span class="badge badge-notifications badge-secondary">(50)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                            </div>



                                        </div>

                                    </div>


                                </div>

                            </label>
                            <!-- end card -->






                            <!-- card  -->
                            <!-- card  -->
                            <label for="meal-breakfast-2" id="meal-breakfast-label-2" class="card-group-row__col carousal-cols meal-breakfast-labels">

                           
                                <input type="checkbox" class="meal-breakfast" name="meal-breakfast[]" id="meal-breakfast-2" value="packageMeal->id">

                                {{-- id of package_meal and meal_type_id --}}
                                <input type="hidden" name="breakfast-package-meal[]" value="packageMeal->id">
                                <input type="hidden" name="breakfast-package-meal-type[]" value="packageMeal->meal_type_id">


                                <div
                                    class="card card-group-row__card text-center o-hidden card--raised custom-schedule-cards ">

                                    <div class="card-body d-flex flex-column">
                                        <div class=" mb-16pt">


                                            <span
                                                class="w-64 h-64 icon-holder icon-holder--outline-accent rounded-circle d-inline-flex mb-16pt mt-3">
                                                <img width="90" height="90" src="{{ asset('assets/customer/images/stories/spicy.png') }}">
                                            </span>
                                            <h4 class="mb-8pt carousal-card-heading">Custom Meal
                                            </h4>
                                            <h6 class="mb-0 text-warning">Breakfast</h6>
                                            <hr class="mt-2">
                                            <h5>Ingredients</h5>

                                            <div style="display: block ruby;">
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Pumpkin<br>
                                                        <span class="badge badge-notifications badge-secondary">(700)
                                                            Gram</span>
                                                    </p>
                                                </div>
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Potato<br>
                                                        <span class="badge badge-notifications badge-secondary">(200)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Gralic<br>
                                                        <span class="badge badge-notifications badge-secondary">(50)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                            </div>



                                        </div>

                                    </div>


                                </div>

                            </label>
                            <!-- end card -->







                            <!-- card  -->
                            <!-- card  -->
                            <label for="meal-breakfast-3" id="meal-breakfast-label-3" class="card-group-row__col carousal-cols meal-breakfast-labels">

                           
                                <input type="checkbox" class="meal-breakfast" name="meal-breakfast[]" id="meal-breakfast-3" value="packageMeal->id">

                                {{-- id of package_meal and meal_type_id --}}
                                <input type="hidden" name="breakfast-package-meal[]" value="packageMeal->id">
                                <input type="hidden" name="breakfast-package-meal-type[]" value="packageMeal->meal_type_id">


                                <div
                                    class="card card-group-row__card text-center o-hidden card--raised custom-schedule-cards ">

                                    <div class="card-body d-flex flex-column">
                                        <div class=" mb-16pt">


                                            <span
                                                class="w-64 h-64 icon-holder icon-holder--outline-accent rounded-circle d-inline-flex mb-16pt mt-3">
                                                <img width="90" height="90" src="{{ asset('assets/customer/images/stories/spicy.png') }}">
                                            </span>
                                            <h4 class="mb-8pt carousal-card-heading">Custom Meal
                                            </h4>
                                            <h6 class="mb-0 text-warning">Breakfast</h6>
                                            <hr class="mt-2">
                                            <h5>Ingredients</h5>

                                            <div style="display: block ruby;">
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Pumpkin<br>
                                                        <span class="badge badge-notifications badge-secondary">(700)
                                                            Gram</span>
                                                    </p>
                                                </div>
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Potato<br>
                                                        <span class="badge badge-notifications badge-secondary">(200)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Gralic<br>
                                                        <span class="badge badge-notifications badge-secondary">(50)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                            </div>



                                        </div>

                                    </div>


                                </div>

                            </label>
                            <!-- end card -->












                            <!-- card  -->
                            <label for="meal-breakfast-4" id="meal-breakfast-label-4" class="card-group-row__col carousal-cols meal-breakfast-labels">

                           
                                <input type="checkbox" class="meal-breakfast" name="meal-breakfast[]" id="meal-breakfast-4" value="packageMeal->id">

                                {{-- id of package_meal and meal_type_id --}}
                                <input type="hidden" name="breakfast-package-meal[]" value="packageMeal->id">
                                <input type="hidden" name="breakfast-package-meal-type[]" value="packageMeal->meal_type_id">


                                <div
                                    class="card card-group-row__card text-center o-hidden card--raised custom-schedule-cards ">

                                    <div class="card-body d-flex flex-column">
                                        <div class=" mb-16pt">


                                            <span
                                                class="w-64 h-64 icon-holder icon-holder--outline-accent rounded-circle d-inline-flex mb-16pt mt-3">
                                                <img width="90" height="90" src="{{ asset('assets/customer/images/stories/spicy.png') }}">
                                            </span>
                                            <h4 class="mb-8pt carousal-card-heading">Custom Meal
                                            </h4>
                                            <h6 class="mb-0 text-warning">Breakfast</h6>
                                            <hr class="mt-2">
                                            <h5>Ingredients</h5>

                                            <div style="display: block ruby;">
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Pumpkin<br>
                                                        <span class="badge badge-notifications badge-secondary">(700)
                                                            Gram</span>
                                                    </p>
                                                </div>
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Potato<br>
                                                        <span class="badge badge-notifications badge-secondary">(200)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Gralic<br>
                                                        <span class="badge badge-notifications badge-secondary">(50)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                            </div>



                                        </div>

                                    </div>


                                </div>

                            </label>
                            <!-- end card -->



                        </div>
                        <!-- end carousal -->




                    </div>
                    <!-- end carousal of meals -->














                    <!-- lunch -->
                    <div id="carousal-breakfast-col" class="form-group col-sm-12 mt-4 pos-relative">

                        <h6 class="mb-1">Lunch</h6>


                        <!-- scroll right and left buttons -->
                        <div class="carousal-buttons-wrapper">

                            <!-- scroll left button -->
                            <button id="horizontal-carousal-button-left-1"
                                class="carousal-scroll-button-left btn btn-primary d-none">
                                <i class="fa fa-chevron-left"></i>
                            </button>

                            <!-- scroll right button -->
                            <button id="horizontal-carousal-button-right-1"
                                class="carousal-scroll-button-right btn btn-primary d-none">
                                <i class="fa fa-chevron-right"></i>
                            </button>

                        </div>

                        <!-- carousal -->
                        <div id="horizontal-carousal-1" class="custom-horizontal-carousal" tabindex=0
                            style="overflow-x: auto;">



                            <!-- card  -->
                            <label for="meal-launch-1" id="meal-launch-label-1" class="card-group-row__col carousal-cols meal-launch-labels">

                           
                                <input type="checkbox" class="meal-launch" name="meal-launch[]" id="meal-launch-1" value="packageMeal->id">

                                {{-- id of package_meal and meal_type_id --}}
                                <input type="hidden" name="launch-package-meal[]" value="packageMeal->id">
                                <input type="hidden" name="launch-package-meal-type[]" value="packageMeal->meal_type_id">


                                <div
                                    class="card card-group-row__card text-center o-hidden card--raised custom-schedule-cards ">

                                    <div class="card-body d-flex flex-column">
                                        <div class=" mb-16pt">


                                            <span
                                                class="w-64 h-64 icon-holder icon-holder--outline-accent rounded-circle d-inline-flex mb-16pt mt-3">
                                                <img width="90" height="90" src="{{ asset('assets/customer/images/stories/spicy.png') }}">
                                            </span>
                                            <h4 class="mb-8pt carousal-card-heading">Custome Meal
                                            </h4>
                                            <h6 class="mb-0 text-warning"> Lunch </h6>
                                            <hr class="mt-2">
                                            <h5>Ingredients</h5>

                                            <div style="display: block ruby;">
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Pumpkin<br>
                                                        <span class="badge badge-notifications badge-secondary">(700)
                                                            Gram</span>
                                                    </p>
                                                </div>
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Potato<br>
                                                        <span class="badge badge-notifications badge-secondary">(200)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Gralic<br>
                                                        <span class="badge badge-notifications badge-secondary">(50)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                            </div>



                                        </div>

                                    </div>


                                </div>

                            </label>
                            <!-- end card -->






                            <!-- card  -->
                            <label for="meal-launch-2" id="meal-launch-label-2" class="card-group-row__col carousal-cols meal-launch-labels">
                            
                            
                                <input type="checkbox" class="meal-launch" name="meal-launch[]" id="meal-launch-2" value="packageMeal->id">
                            
                                {{-- id of package_meal and meal_type_id --}}
                                <input type="hidden" name="launch-package-meal[]" value="packageMeal->id">
                                <input type="hidden" name="launch-package-meal-type[]" value="packageMeal->meal_type_id">


                                <div
                                    class="card card-group-row__card text-center o-hidden card--raised custom-schedule-cards ">

                                    <div class="card-body d-flex flex-column">
                                        <div class=" mb-16pt">


                                            <span
                                                class="w-64 h-64 icon-holder icon-holder--outline-accent rounded-circle d-inline-flex mb-16pt mt-3">
                                                <img width="90" height="90" src="{{ asset('assets/customer/images/stories/spicy.png') }}">
                                            </span>
                                            <h4 class="mb-8pt carousal-card-heading">Custom Meal
                                            </h4>
                                            <h6 class="mb-0 text-warning">Lunch</h6>
                                            <hr class="mt-2">
                                            <h5>Ingredients</h5>

                                            <div style="display: block ruby;">
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Pumpkin<br>
                                                        <span class="badge badge-notifications badge-secondary">(700)
                                                            Gram</span>
                                                    </p>
                                                </div>
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Potato<br>
                                                        <span class="badge badge-notifications badge-secondary">(200)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Gralic<br>
                                                        <span class="badge badge-notifications badge-secondary">(50)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                            </div>



                                        </div>

                                    </div>


                                </div>

                            </label>
                            <!-- end card -->







                            <!-- card  -->
                            <label for="meal-launch-3" id="meal-launch-label-3" class="card-group-row__col carousal-cols meal-launch-labels">
                            
                            
                                <input type="checkbox" class="meal-launch" name="meal-launch[]" id="meal-launch-3" value="packageMeal->id">
                            
                                {{-- id of package_meal and meal_type_id --}}
                                <input type="hidden" name="launch-package-meal[]" value="packageMeal->id">
                                <input type="hidden" name="launch-package-meal-type[]" value="packageMeal->meal_type_id">


                                <div
                                    class="card card-group-row__card text-center o-hidden card--raised custom-schedule-cards ">

                                    <div class="card-body d-flex flex-column">
                                        <div class=" mb-16pt">


                                            <span
                                                class="w-64 h-64 icon-holder icon-holder--outline-accent rounded-circle d-inline-flex mb-16pt mt-3">
                                                <img width="90" height="90" src="{{ asset('assets/customer/images/stories/spicy.png') }}">
                                            </span>
                                            <h4 class="mb-8pt carousal-card-heading">Custom Meal
                                            </h4>
                                            <h6 class="mb-0 text-warning">Lunch</h6>
                                            <hr class="mt-2">
                                            <h5>Ingredients</h5>

                                            <div style="display: block ruby;">
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Pumpkin<br>
                                                        <span class="badge badge-notifications badge-secondary">(700)
                                                            Gram</span>
                                                    </p>
                                                </div>
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Potato<br>
                                                        <span class="badge badge-notifications badge-secondary">(200)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Gralic<br>
                                                        <span class="badge badge-notifications badge-secondary">(50)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                            </div>



                                        </div>

                                    </div>


                                </div>

                            </label>
                            <!-- end card -->












                            <!-- card  -->
                            <label for="meal-launch-4" id="meal-launch-label-4" class="card-group-row__col carousal-cols meal-launch-labels">
                            
                            
                                <input type="checkbox" class="meal-launch" name="meal-launch[]" id="meal-launch-4" value="packageMeal->id">
                            
                                {{-- id of package_meal and meal_type_id --}}
                                <input type="hidden" name="launch-package-meal[]" value="packageMeal->id">
                                <input type="hidden" name="launch-package-meal-type[]" value="packageMeal->meal_type_id">


                                <div
                                    class="card card-group-row__card text-center o-hidden card--raised custom-schedule-cards ">

                                    <div class="card-body d-flex flex-column">
                                        <div class=" mb-16pt">


                                            <span
                                                class="w-64 h-64 icon-holder icon-holder--outline-accent rounded-circle d-inline-flex mb-16pt mt-3">
                                                <img width="90" height="90" src="{{ asset('assets/customer/images/stories/spicy.png') }}">
                                            </span>
                                            <h4 class="mb-8pt carousal-card-heading">Custom Meal
                                            </h4>
                                            <h6 class="mb-0 text-warning">Lunch</h6>
                                            <hr class="mt-2">
                                            <h5>Ingredients</h5>

                                            <div style="display: block ruby;">
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Pumpkin<br>
                                                        <span class="badge badge-notifications badge-secondary">(700)
                                                            Gram</span>
                                                    </p>
                                                </div>
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Potato<br>
                                                        <span class="badge badge-notifications badge-secondary">(200)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Gralic<br>
                                                        <span class="badge badge-notifications badge-secondary">(50)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                            </div>



                                        </div>

                                    </div>


                                </div>

                            </label>
                            <!-- end card -->



                        </div>
                        <!-- end carousal -->




                    </div>
                    <!-- end carousal of meals -->







                    <!-- hr -->
                    <div class="col-12">
                        <hr>
                    </div>


                    <!-- dinner -->
                    <div id="carousal-breakfast-col" class="form-group col-sm-12 mt-4 pos-relative">


                        <h6 class="mb-1">Dinner</h6>


                        <!-- scroll right and left buttons -->
                        <div class="carousal-buttons-wrapper">

                            <!-- scroll left button -->
                            <button id="horizontal-carousal-button-left-1"
                                class="carousal-scroll-button-left btn btn-primary d-none">
                                <i class="fa fa-chevron-left"></i>
                            </button>

                            <!-- scroll right button -->
                            <button id="horizontal-carousal-button-right-1"
                                class="carousal-scroll-button-right btn btn-primary d-none">
                                <i class="fa fa-chevron-right"></i>
                            </button>

                        </div>

                        <!-- carousal -->
                        <div id="horizontal-carousal-1" class="custom-horizontal-carousal" tabindex=0
                            style="overflow-x: auto;">



                            <!-- card  -->
                            <label for="meal-dinner-1" id="meal-dinner-label-1" class="card-group-row__col carousal-cols meal-dinner-labels">
                            
                            
                                <input type="checkbox" class="meal-dinner" name="meal-dinner[]" id="meal-dinner-1" value="packageMeal->id">
                            
                                {{-- id of package_meal and meal_type_id --}}
                                <input type="hidden" name="dinner-package-meal[]" value="packageMeal->id">
                                <input type="hidden" name="dinner-package-meal-type[]" value="packageMeal->meal_type_id">


                                <div
                                    class="card card-group-row__card text-center o-hidden card--raised custom-schedule-cards ">

                                    <div class="card-body d-flex flex-column">
                                        <div class=" mb-16pt">


                                            <span
                                                class="w-64 h-64 icon-holder icon-holder--outline-accent rounded-circle d-inline-flex mb-16pt mt-3">
                                                <img width="90" height="90" src="{{ asset('assets/customer/images/stories/spicy.png') }}">
                                            </span>
                                            <h4 class="mb-8pt carousal-card-heading">Custome Meal
                                            </h4>
                                            <h6 class="mb-0 text-warning"> Dinner </h6>
                                            <hr class="mt-2">
                                            <h5>Ingredients</h5>

                                            <div style="display: block ruby;">
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Pumpkin<br>
                                                        <span class="badge badge-notifications badge-secondary">(700)
                                                            Gram</span>
                                                    </p>
                                                </div>
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Potato<br>
                                                        <span class="badge badge-notifications badge-secondary">(200)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Gralic<br>
                                                        <span class="badge badge-notifications badge-secondary">(50)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                            </div>



                                        </div>

                                    </div>


                                </div>

                            </label>
                            <!-- end card -->






                            <!-- card  -->
                            <label for="meal-dinner-2" id="meal-dinner-label-2" class="card-group-row__col carousal-cols meal-dinner-labels">
                            
                            
                                <input type="checkbox" class="meal-dinner" name="meal-dinner[]" id="meal-dinner-2" value="packageMeal->id">
                            
                                {{-- id of package_meal and meal_type_id --}}
                                <input type="hidden" name="dinner-package-meal[]" value="packageMeal->id">
                                <input type="hidden" name="dinner-package-meal-type[]" value="packageMeal->meal_type_id">


                                <div
                                    class="card card-group-row__card text-center o-hidden card--raised custom-schedule-cards ">

                                    <div class="card-body d-flex flex-column">
                                        <div class=" mb-16pt">


                                            <span
                                                class="w-64 h-64 icon-holder icon-holder--outline-accent rounded-circle d-inline-flex mb-16pt mt-3">
                                                <img width="90" height="90" src="{{ asset('assets/customer/images/stories/spicy.png') }}">
                                            </span>
                                            <h4 class="mb-8pt carousal-card-heading">Custom Meal
                                            </h4>
                                            <h6 class="mb-0 text-warning">Dinner</h6>
                                            <hr class="mt-2">
                                            <h5>Ingredients</h5>

                                            <div style="display: block ruby;">
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Pumpkin<br>
                                                        <span class="badge badge-notifications badge-secondary">(700)
                                                            Gram</span>
                                                    </p>
                                                </div>
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Potato<br>
                                                        <span class="badge badge-notifications badge-secondary">(200)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Gralic<br>
                                                        <span class="badge badge-notifications badge-secondary">(50)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                            </div>



                                        </div>

                                    </div>


                                </div>

                            </label>
                            <!-- end card -->







                            <!-- card  -->
                            <label for="meal-dinner-3" id="meal-dinner-label-3" class="card-group-row__col carousal-cols meal-dinner-labels">
                            
                            
                                <input type="checkbox" class="meal-dinner" name="meal-dinner[]" id="meal-dinner-3" value="packageMeal->id">
                            
                                {{-- id of package_meal and meal_type_id --}}
                                <input type="hidden" name="dinner-package-meal[]" value="packageMeal->id">
                                <input type="hidden" name="dinner-package-meal-type[]" value="packageMeal->meal_type_id">


                                <div
                                    class="card card-group-row__card text-center o-hidden card--raised custom-schedule-cards ">

                                    <div class="card-body d-flex flex-column">
                                        <div class=" mb-16pt">


                                            <span
                                                class="w-64 h-64 icon-holder icon-holder--outline-accent rounded-circle d-inline-flex mb-16pt mt-3">
                                                <img width="90" height="90" src="{{ asset('assets/customer/images/stories/spicy.png') }}">
                                            </span>
                                            <h4 class="mb-8pt carousal-card-heading">Custom Meal
                                            </h4>
                                            <h6 class="mb-0 text-warning">Dinner</h6>
                                            <hr class="mt-2">
                                            <h5>Ingredients</h5>

                                            <div style="display: block ruby;">
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Pumpkin<br>
                                                        <span class="badge badge-notifications badge-secondary">(700)
                                                            Gram</span>
                                                    </p>
                                                </div>
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Potato<br>
                                                        <span class="badge badge-notifications badge-secondary">(200)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Gralic<br>
                                                        <span class="badge badge-notifications badge-secondary">(50)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                            </div>



                                        </div>

                                    </div>


                                </div>

                            </label>
                            <!-- end card -->












                            <!-- card  -->
                            <label for="meal-dinner-4" id="meal-dinner-label-4" class="card-group-row__col carousal-cols meal-dinner-labels">
                            
                            
                                <input type="checkbox" class="meal-dinner" name="meal-dinner[]" id="meal-dinner-4" value="packageMeal->id">
                            
                                {{-- id of package_meal and meal_type_id --}}
                                <input type="hidden" name="dinner-package-meal[]" value="packageMeal->id">
                                <input type="hidden" name="dinner-package-meal-type[]" value="packageMeal->meal_type_id">


                                <div
                                    class="card card-group-row__card text-center o-hidden card--raised custom-schedule-cards ">

                                    <div class="card-body d-flex flex-column">
                                        <div class=" mb-16pt">


                                            <span
                                                class="w-64 h-64 icon-holder icon-holder--outline-accent rounded-circle d-inline-flex mb-16pt mt-3">
                                                <img width="90" height="90" src="{{ asset('assets/customer/images/stories/spicy.png') }}">
                                            </span>
                                            <h4 class="mb-8pt carousal-card-heading">Custom Meal
                                            </h4>
                                            <h6 class="mb-0 text-warning">Dinner</h6>
                                            <hr class="mt-2">
                                            <h5>Ingredients</h5>

                                            <div style="display: block ruby;">
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Pumpkin<br>
                                                        <span class="badge badge-notifications badge-secondary">(700)
                                                            Gram</span>
                                                    </p>
                                                </div>
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Potato<br>
                                                        <span class="badge badge-notifications badge-secondary">(200)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Gralic<br>
                                                        <span class="badge badge-notifications badge-secondary">(50)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                            </div>



                                        </div>

                                    </div>


                                </div>

                            </label>
                            <!-- end card -->



                        </div>
                        <!-- end carousal -->




                    </div>
                    <!-- end carousal of meals -->













                    <!-- snack -->
                    <div id="carousal-breakfast-col" class="form-group col-sm-12 mt-4 pos-relative">


                        <h6 class="mb-1">Snack</h6>


                        <!-- scroll right and left buttons -->
                        <div class="carousal-buttons-wrapper">

                            <!-- scroll left button -->
                            <button id="horizontal-carousal-button-left-1"
                                class="carousal-scroll-button-left btn btn-primary d-none">
                                <i class="fa fa-chevron-left"></i>
                            </button>

                            <!-- scroll right button -->
                            <button id="horizontal-carousal-button-right-1"
                                class="carousal-scroll-button-right btn btn-primary d-none">
                                <i class="fa fa-chevron-right"></i>
                            </button>

                        </div>

                        <!-- carousal -->
                        <div id="horizontal-carousal-1" class="custom-horizontal-carousal" tabindex=0
                            style="overflow-x: auto;">



                            <!-- card  -->
                            <label for="meal-snack-1" id="meal-snack-label-1" class="card-group-row__col carousal-cols meal-snack-labels">
                            
                            
                                <input type="checkbox" class="meal-snack" name="meal-snack[]" id="meal-snack-1" value="packageMeal->id">
                            
                                {{-- id of package_meal and meal_type_id --}}
                                <input type="hidden" name="snack-package-meal[]" value="packageMeal->id">
                                <input type="hidden" name="snack-package-meal-type[]" value="packageMeal->meal_type_id">


                                <div
                                    class="card card-group-row__card text-center o-hidden card--raised custom-schedule-cards ">

                                    <div class="card-body d-flex flex-column">
                                        <div class=" mb-16pt">


                                            <span
                                                class="w-64 h-64 icon-holder icon-holder--outline-accent rounded-circle d-inline-flex mb-16pt mt-3">
                                                <img width="90" height="90" src="{{ asset('assets/customer/images/stories/spicy.png') }}">
                                            </span>
                                            <h4 class="mb-8pt carousal-card-heading">Custome Meal
                                            </h4>
                                            <h6 class="mb-0 text-warning"> Snack </h6>
                                            <hr class="mt-2">
                                            <h5>Ingredients</h5>

                                            <div style="display: block ruby;">
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Pumpkin<br>
                                                        <span class="badge badge-notifications badge-secondary">(700)
                                                            Gram</span>
                                                    </p>
                                                </div>
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Potato<br>
                                                        <span class="badge badge-notifications badge-secondary">(200)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Gralic<br>
                                                        <span class="badge badge-notifications badge-secondary">(50)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                            </div>



                                        </div>

                                    </div>


                                </div>

                            </label>
                            <!-- end card -->






                            <!-- card  -->
                            <label for="meal-snack-2" id="meal-snack-label-2" class="card-group-row__col carousal-cols meal-snack-labels">
                            
                            
                                <input type="checkbox" class="meal-snack" name="meal-snack[]" id="meal-snack-2" value="packageMeal->id">
                            
                                {{-- id of package_meal and meal_type_id --}}
                                <input type="hidden" name="snack-package-meal[]" value="packageMeal->id">
                                <input type="hidden" name="snack-package-meal-type[]" value="packageMeal->meal_type_id">


                                <div
                                    class="card card-group-row__card text-center o-hidden card--raised custom-schedule-cards ">

                                    <div class="card-body d-flex flex-column">
                                        <div class=" mb-16pt">


                                            <span
                                                class="w-64 h-64 icon-holder icon-holder--outline-accent rounded-circle d-inline-flex mb-16pt mt-3">
                                                <img width="90" height="90" src="{{ asset('assets/customer/images/stories/spicy.png') }}">
                                            </span>
                                            <h4 class="mb-8pt carousal-card-heading">Custom Meal
                                            </h4>
                                            <h6 class="mb-0 text-warning">Snack</h6>
                                            <hr class="mt-2">
                                            <h5>Ingredients</h5>

                                            <div style="display: block ruby;">
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Pumpkin<br>
                                                        <span class="badge badge-notifications badge-secondary">(700)
                                                            Gram</span>
                                                    </p>
                                                </div>
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Potato<br>
                                                        <span class="badge badge-notifications badge-secondary">(200)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Gralic<br>
                                                        <span class="badge badge-notifications badge-secondary">(50)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                            </div>



                                        </div>

                                    </div>


                                </div>

                            </label>
                            <!-- end card -->







                            <!-- card  -->
                            <label for="meal-snack-3" id="meal-snack-label-3" class="card-group-row__col carousal-cols meal-snack-labels">
                            
                            
                                <input type="checkbox" class="meal-snack" name="meal-snack[]" id="meal-snack-3" value="packageMeal->id">
                            
                                {{-- id of package_meal and meal_type_id --}}
                                <input type="hidden" name="snack-package-meal[]" value="packageMeal->id">
                                <input type="hidden" name="snack-package-meal-type[]" value="packageMeal->meal_type_id">


                                <div
                                    class="card card-group-row__card text-center o-hidden card--raised custom-schedule-cards ">

                                    <div class="card-body d-flex flex-column">
                                        <div class=" mb-16pt">


                                            <span
                                                class="w-64 h-64 icon-holder icon-holder--outline-accent rounded-circle d-inline-flex mb-16pt mt-3">
                                                <img width="90" height="90" src="{{ asset('assets/customer/images/stories/spicy.png') }}">
                                            </span>
                                            <h4 class="mb-8pt carousal-card-heading">Custom Meal
                                            </h4>
                                            <h6 class="mb-0 text-warning">Snack</h6>
                                            <hr class="mt-2">
                                            <h5>Ingredients</h5>

                                            <div style="display: block ruby;">
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Pumpkin<br>
                                                        <span class="badge badge-notifications badge-secondary">(700)
                                                            Gram</span>
                                                    </p>
                                                </div>
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Potato<br>
                                                        <span class="badge badge-notifications badge-secondary">(200)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Gralic<br>
                                                        <span class="badge badge-notifications badge-secondary">(50)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                            </div>



                                        </div>

                                    </div>


                                </div>

                            </label>
                            <!-- end card -->












                            <!-- card  -->
                            <label for="meal-snack-4" id="meal-snack-label-4" class="card-group-row__col carousal-cols meal-snack-labels">
                            
                            
                                <input type="checkbox" class="meal-snack" name="meal-snack[]" id="meal-snack-4" value="packageMeal->id">
                            
                                {{-- id of package_meal and meal_type_id --}}
                                <input type="hidden" name="snack-package-meal[]" value="packageMeal->id">
                                <input type="hidden" name="snack-package-meal-type[]" value="packageMeal->meal_type_id">


                                <div
                                    class="card card-group-row__card text-center o-hidden card--raised custom-schedule-cards ">

                                    <div class="card-body d-flex flex-column">
                                        <div class=" mb-16pt">


                                            <span
                                                class="w-64 h-64 icon-holder icon-holder--outline-accent rounded-circle d-inline-flex mb-16pt mt-3">
                                                <img width="90" height="90" src="{{ asset('assets/customer/images/stories/spicy.png') }}">
                                            </span>
                                            <h4 class="mb-8pt carousal-card-heading">Custom Meal
                                            </h4>
                                            <h6 class="mb-0 text-warning">Snack</h6>
                                            <hr class="mt-2">
                                            <h5>Ingredients</h5>

                                            <div style="display: block ruby;">
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Pumpkin<br>
                                                        <span class="badge badge-notifications badge-secondary">(700)
                                                            Gram</span>
                                                    </p>
                                                </div>
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Potato<br>
                                                        <span class="badge badge-notifications badge-secondary">(200)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Gralic<br>
                                                        <span class="badge badge-notifications badge-secondary">(50)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                            </div>



                                        </div>

                                    </div>


                                </div>

                            </label>
                            <!-- end card -->



                        </div>
                        <!-- end carousal -->




                    </div>
                    <!-- end carousal of meals -->












                    <!-- Pre Workout -->
                    <div id="carousal-breakfast-col" class="form-group col-sm-12 mt-4 pos-relative">


                        <h6 class="mb-1">Pre-Workout</h6>


                        <!-- scroll right and left buttons -->
                        <div class="carousal-buttons-wrapper">

                            <!-- scroll left button -->
                            <button id="horizontal-carousal-button-left-1"
                                class="carousal-scroll-button-left btn btn-primary d-none">
                                <i class="fa fa-chevron-left"></i>
                            </button>

                            <!-- scroll right button -->
                            <button id="horizontal-carousal-button-right-1"
                                class="carousal-scroll-button-right btn btn-primary d-none">
                                <i class="fa fa-chevron-right"></i>
                            </button>

                        </div>

                        <!-- carousal -->
                        <div id="horizontal-carousal-1" class="custom-horizontal-carousal" tabindex=0
                            style="overflow-x: auto;">



                            <!-- card  -->
                            <label for="meal-preworkout-1" id="meal-preworkout-label-1" class="card-group-row__col carousal-cols meal-preworkout-labels">
                            
                            
                                <input type="checkbox" class="meal-preworkout" name="meal-preworkout[]" id="meal-preworkout-1" value="packageMeal->id">
                            
                                {{-- id of package_meal and meal_type_id --}}
                                <input type="hidden" name="preworkout-package-meal[]" value="packageMeal->id">
                                <input type="hidden" name="preworkout-package-meal-type[]" value="packageMeal->meal_type_id">


                                <div
                                    class="card card-group-row__card text-center o-hidden card--raised custom-schedule-cards ">

                                    <div class="card-body d-flex flex-column">
                                        <div class=" mb-16pt">


                                            <span
                                                class="w-64 h-64 icon-holder icon-holder--outline-accent rounded-circle d-inline-flex mb-16pt mt-3">
                                                <img width="90" height="90" src="{{ asset('assets/customer/images/stories/spicy.png') }}">
                                            </span>
                                            <h4 class="mb-8pt carousal-card-heading">Custome Meal
                                            </h4>
                                            <h6 class="mb-0 text-warning"> Pre-Workout </h6>
                                            <hr class="mt-2">
                                            <h5>Ingredients</h5>

                                            <div style="display: block ruby;">
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Pumpkin<br>
                                                        <span class="badge badge-notifications badge-secondary">(700)
                                                            Gram</span>
                                                    </p>
                                                </div>
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Potato<br>
                                                        <span class="badge badge-notifications badge-secondary">(200)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Gralic<br>
                                                        <span class="badge badge-notifications badge-secondary">(50)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                            </div>



                                        </div>

                                    </div>


                                </div>

                            </label>
                            <!-- end card -->






                            <!-- card  -->
                            <label for="meal-preworkout-2" id="meal-preworkout-label-2" class="card-group-row__col carousal-cols meal-preworkout-labels">
                            
                            
                                <input type="checkbox" class="meal-preworkout" name="meal-preworkout[]" id="meal-preworkout-2" value="packageMeal->id">
                            
                                {{-- id of package_meal and meal_type_id --}}
                                <input type="hidden" name="preworkout-package-meal[]" value="packageMeal->id">
                                <input type="hidden" name="preworkout-package-meal-type[]" value="packageMeal->meal_type_id">


                                <div
                                    class="card card-group-row__card text-center o-hidden card--raised custom-schedule-cards ">

                                    <div class="card-body d-flex flex-column">
                                        <div class=" mb-16pt">


                                            <span
                                                class="w-64 h-64 icon-holder icon-holder--outline-accent rounded-circle d-inline-flex mb-16pt mt-3">
                                                <img width="90" height="90" src="{{ asset('assets/customer/images/stories/spicy.png') }}">
                                            </span>
                                            <h4 class="mb-8pt carousal-card-heading">Custom Meal
                                            </h4>
                                            <h6 class="mb-0 text-warning">Pre-Workout</h6>
                                            <hr class="mt-2">
                                            <h5>Ingredients</h5>

                                            <div style="display: block ruby;">
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Pumpkin<br>
                                                        <span class="badge badge-notifications badge-secondary">(700)
                                                            Gram</span>
                                                    </p>
                                                </div>
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Potato<br>
                                                        <span class="badge badge-notifications badge-secondary">(200)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Gralic<br>
                                                        <span class="badge badge-notifications badge-secondary">(50)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                            </div>



                                        </div>

                                    </div>


                                </div>

                            </label>
                            <!-- end card -->







                            <!-- card  -->
                            <label for="meal-preworkout-3" id="meal-preworkout-label-3"
                                class="card-group-row__col carousal-cols meal-preworkout-labels">
                            
                            
                                <input type="checkbox" class="meal-preworkout" name="meal-preworkout[]" id="meal-preworkout-3"
                                    value="packageMeal->id">
                            
                                {{-- id of package_meal and meal_type_id --}}
                                <input type="hidden" name="preworkout-package-meal[]" value="packageMeal->id">
                                <input type="hidden" name="preworkout-package-meal-type[]" value="packageMeal->meal_type_id">


                                <div
                                    class="card card-group-row__card text-center o-hidden card--raised custom-schedule-cards ">

                                    <div class="card-body d-flex flex-column">
                                        <div class=" mb-16pt">


                                            <span
                                                class="w-64 h-64 icon-holder icon-holder--outline-accent rounded-circle d-inline-flex mb-16pt mt-3">
                                                <img width="90" height="90" src="{{ asset('assets/customer/images/stories/spicy.png') }}">
                                            </span>
                                            <h4 class="mb-8pt carousal-card-heading">Custom Meal
                                            </h4>
                                            <h6 class="mb-0 text-warning">Pre-Workout</h6>
                                            <hr class="mt-2">
                                            <h5>Ingredients</h5>

                                            <div style="display: block ruby;">
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Pumpkin<br>
                                                        <span class="badge badge-notifications badge-secondary">(700)
                                                            Gram</span>
                                                    </p>
                                                </div>
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Potato<br>
                                                        <span class="badge badge-notifications badge-secondary">(200)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Gralic<br>
                                                        <span class="badge badge-notifications badge-secondary">(50)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                            </div>



                                        </div>

                                    </div>


                                </div>

                            </label>
                            <!-- end card -->












                            <!-- card  -->
                            <label for="meal-preworkout-4" id="meal-preworkout-label-4"
                                class="card-group-row__col carousal-cols meal-preworkout-labels">
                            
                            
                                <input type="checkbox" class="meal-preworkout" name="meal-preworkout[]" id="meal-preworkout-4"
                                    value="packageMeal->id">
                            
                                {{-- id of package_meal and meal_type_id --}}
                                <input type="hidden" name="preworkout-package-meal[]" value="packageMeal->id">
                                <input type="hidden" name="preworkout-package-meal-type[]" value="packageMeal->meal_type_id">


                                <div
                                    class="card card-group-row__card text-center o-hidden card--raised custom-schedule-cards ">

                                    <div class="card-body d-flex flex-column">
                                        <div class=" mb-16pt">


                                            <span
                                                class="w-64 h-64 icon-holder icon-holder--outline-accent rounded-circle d-inline-flex mb-16pt mt-3">
                                                <img width="90" height="90" src="{{ asset('assets/customer/images/stories/spicy.png') }}">
                                            </span>
                                            <h4 class="mb-8pt carousal-card-heading">Custom Meal
                                            </h4>
                                            <h6 class="mb-0 text-warning">Pre-Workout</h6>
                                            <hr class="mt-2">
                                            <h5>Ingredients</h5>

                                            <div style="display: block ruby;">
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Pumpkin<br>
                                                        <span class="badge badge-notifications badge-secondary">(700)
                                                            Gram</span>
                                                    </p>
                                                </div>
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Potato<br>
                                                        <span class="badge badge-notifications badge-secondary">(200)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Gralic<br>
                                                        <span class="badge badge-notifications badge-secondary">(50)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                            </div>



                                        </div>

                                    </div>


                                </div>

                            </label>
                            <!-- end card -->



                        </div>
                        <!-- end carousal -->




                    </div>
                    <!-- end carousal of meals -->














                    <!-- post workout -->
                    <div id="carousal-breakfast-col" class="form-group col-sm-12 mt-4 pos-relative">


                        <h6 class="mb-1">Post-Workout</h6>


                        <!-- scroll right and left buttons -->
                        <div class="carousal-buttons-wrapper">

                            <!-- scroll left button -->
                            <button id="horizontal-carousal-button-left-1"
                                class="carousal-scroll-button-left btn btn-primary d-none">
                                <i class="fa fa-chevron-left"></i>
                            </button>

                            <!-- scroll right button -->
                            <button id="horizontal-carousal-button-right-1"
                                class="carousal-scroll-button-right btn btn-primary d-none">
                                <i class="fa fa-chevron-right"></i>
                            </button>

                        </div>

                        <!-- carousal -->
                        <div id="horizontal-carousal-1" class="custom-horizontal-carousal" tabindex=0
                            style="overflow-x: auto;">



                            <!-- card  -->
                            <label for="meal-postworkout-1" id="meal-postworkout-label-1"
                                class="card-group-row__col carousal-cols meal-postworkout-labels">
                            
                            
                                <input type="checkbox" class="meal-postworkout" name="meal-postworkout[]" id="meal-postworkout-1"
                                    value="packageMeal->id">
                            
                                {{-- id of package_meal and meal_type_id --}}
                                <input type="hidden" name="postworkout-package-meal[]" value="packageMeal->id">
                                <input type="hidden" name="postworkout-package-meal-type[]" value="packageMeal->meal_type_id">


                                <div
                                    class="card card-group-row__card text-center o-hidden card--raised custom-schedule-cards ">

                                    <div class="card-body d-flex flex-column">
                                        <div class=" mb-16pt">


                                            <span
                                                class="w-64 h-64 icon-holder icon-holder--outline-accent rounded-circle d-inline-flex mb-16pt mt-3">
                                                <img width="90" height="90" src="{{ asset('assets/customer/images/stories/spicy.png') }}">
                                            </span>
                                            <h4 class="mb-8pt carousal-card-heading">Custome Meal
                                            </h4>
                                            <h6 class="mb-0 text-warning"> Post-Workout </h6>
                                            <hr class="mt-2">
                                            <h5>Ingredients</h5>

                                            <div style="display: block ruby;">
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Pumpkin<br>
                                                        <span class="badge badge-notifications badge-secondary">(700)
                                                            Gram</span>
                                                    </p>
                                                </div>
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Potato<br>
                                                        <span class="badge badge-notifications badge-secondary">(200)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Gralic<br>
                                                        <span class="badge badge-notifications badge-secondary">(50)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                            </div>



                                        </div>

                                    </div>


                                </div>

                            </label>
                            <!-- end card -->






                            <!-- card  -->
                            <label for="meal-postworkout-2" id="meal-postworkout-label-2"
                                class="card-group-row__col carousal-cols meal-postworkout-labels">
                            
                            
                                <input type="checkbox" class="meal-postworkout" name="meal-postworkout[]" id="meal-postworkout-2"
                                    value="packageMeal->id">
                            
                                {{-- id of package_meal and meal_type_id --}}
                                <input type="hidden" name="postworkout-package-meal[]" value="packageMeal->id">
                                <input type="hidden" name="postworkout-package-meal-type[]" value="packageMeal->meal_type_id">


                                <div
                                    class="card card-group-row__card text-center o-hidden card--raised custom-schedule-cards ">

                                    <div class="card-body d-flex flex-column">
                                        <div class=" mb-16pt">


                                            <span
                                                class="w-64 h-64 icon-holder icon-holder--outline-accent rounded-circle d-inline-flex mb-16pt mt-3">
                                                <img width="90" height="90" src="{{ asset('assets/customer/images/stories/spicy.png') }}">
                                            </span>
                                            <h4 class="mb-8pt carousal-card-heading">Custom Meal
                                            </h4>
                                            <h6 class="mb-0 text-warning">Post-Workout</h6>
                                            <hr class="mt-2">
                                            <h5>Ingredients</h5>

                                            <div style="display: block ruby;">
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Pumpkin<br>
                                                        <span class="badge badge-notifications badge-secondary">(700)
                                                            Gram</span>
                                                    </p>
                                                </div>
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Potato<br>
                                                        <span class="badge badge-notifications badge-secondary">(200)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Gralic<br>
                                                        <span class="badge badge-notifications badge-secondary">(50)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                            </div>



                                        </div>

                                    </div>


                                </div>

                            </label>
                            <!-- end card -->







                            <!-- card  -->
                            <label for="meal-postworkout-3" id="meal-postworkout-label-3"
                                class="card-group-row__col carousal-cols meal-postworkout-labels">
                            
                            
                                <input type="checkbox" class="meal-postworkout" name="meal-postworkout[]" id="meal-postworkout-3"
                                    value="packageMeal->id">
                            
                                {{-- id of package_meal and meal_type_id --}}
                                <input type="hidden" name="postworkout-package-meal[]" value="packageMeal->id">
                                <input type="hidden" name="postworkout-package-meal-type[]" value="packageMeal->meal_type_id">


                                <div
                                    class="card card-group-row__card text-center o-hidden card--raised custom-schedule-cards ">

                                    <div class="card-body d-flex flex-column">
                                        <div class=" mb-16pt">


                                            <span
                                                class="w-64 h-64 icon-holder icon-holder--outline-accent rounded-circle d-inline-flex mb-16pt mt-3">
                                                <img width="90" height="90" src="{{ asset('assets/customer/images/stories/spicy.png') }}">
                                            </span>
                                            <h4 class="mb-8pt carousal-card-heading">Custom Meal
                                            </h4>
                                            <h6 class="mb-0 text-warning">Post-Workout</h6>
                                            <hr class="mt-2">
                                            <h5>Ingredients</h5>

                                            <div style="display: block ruby;">
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Pumpkin<br>
                                                        <span class="badge badge-notifications badge-secondary">(700)
                                                            Gram</span>
                                                    </p>
                                                </div>
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Potato<br>
                                                        <span class="badge badge-notifications badge-secondary">(200)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Gralic<br>
                                                        <span class="badge badge-notifications badge-secondary">(50)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                            </div>



                                        </div>

                                    </div>


                                </div>

                            </label>
                            <!-- end card -->












                            <!-- card  -->
                            <label for="meal-postworkout-4" id="meal-postworkout-label-4"
                                class="card-group-row__col carousal-cols meal-postworkout-labels">
                            
                            
                                <input type="checkbox" class="meal-postworkout" name="meal-postworkout[]" id="meal-postworkout-4"
                                    value="packageMeal->id">
                            
                                {{-- id of package_meal and meal_type_id --}}
                                <input type="hidden" name="postworkout-package-meal[]" value="packageMeal->id">
                                <input type="hidden" name="postworkout-package-meal-type[]" value="packageMeal->meal_type_id">


                                <div
                                    class="card card-group-row__card text-center o-hidden card--raised custom-schedule-cards ">

                                    <div class="card-body d-flex flex-column">
                                        <div class=" mb-16pt">


                                            <span
                                                class="w-64 h-64 icon-holder icon-holder--outline-accent rounded-circle d-inline-flex mb-16pt mt-3">
                                                <img width="90" height="90" src="{{ asset('assets/customer/images/stories/spicy.png') }}">
                                            </span>
                                            <h4 class="mb-8pt carousal-card-heading">Custom Meal
                                            </h4>
                                            <h6 class="mb-0 text-warning">Post-Workout</h6>
                                            <hr class="mt-2">
                                            <h5>Ingredients</h5>

                                            <div style="display: block ruby;">
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Pumpkin<br>
                                                        <span class="badge badge-notifications badge-secondary">(700)
                                                            Gram</span>
                                                    </p>
                                                </div>
                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Potato<br>
                                                        <span class="badge badge-notifications badge-secondary">(200)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                                <div>
                                                    <p class="text-70 mb-0" style="font-weight: bold; ">Gralic<br>
                                                        <span class="badge badge-notifications badge-secondary">(50)
                                                            Gram</span>
                                                    </p>
                                                </div>

                                            </div>



                                        </div>

                                    </div>


                                </div>

                            </label>
                            <!-- end card -->



                        </div>
                        <!-- end carousal -->




                    </div>
                    <!-- end carousal of meals -->



                    <div class="col-12 text-center mt-3 mb-5">
                        <a href="{{ route('customer.plan') }}" class="btn mr-2 btn-white px-5 py-1">
                            back
                        </a>

                        <button class="btn py-1 btn-primary px-5">
                            Save
                        </button>
                    </div>
                </div>
                <!-- end row -->


            </div>
        </div>
        <!-- breadcrubms end -->



        <div class="container page__container">
            <div class="page-section">




            </div>
        </div>





    </div>
    <!-- // END drawer-layout__content -->




    <!-- drawrer menu was here -->

    <!-- drawrer menu end -->



</div>





@endsection






{{-- scripts --}}
@section('scripts')

    <!-- package plan js (custom added) -->
    <script src="{{ asset('assets/admin/js/package-plan.js') }}"></script>
    
    
    <!-- package plan js (custom added) -->
    <script src="{{ asset('assets/customer/js/customer-mobile.js') }}"></script>

@endsection








{{-- modals --}}
@section('modals')


<!-- package modal -->
<div class="modal fade package-info" data-backdrop="false" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-sm" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel" style="letter-spacing: 0.4px !important;">Package
                    Description</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body">

                <div class="row">
                    <div class="col-12">

                        <p class="mb-0" style="color:dimgrey;">Perfect 6 pack food. Lean protein, Minimal carbohydrates
                            and lots of vegetables.
                            Average calories per meal is around 300 to 350 Kcal. All meals shown on this page are Sample
                            Meals.</p>

                    </div>


                </div>


            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<!-- end package modal -->











<!-- exclude modal -->
<div class="modal fade exclude-modal" data-backdrop="false" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-sm" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel" style="letter-spacing: 0.4px !important;">Exclude
                    Ingredients</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body">

                <div class="row">

                    <div class="col-12 mb-2">
                        <span class="" style="color:dimgrey;"><i class="fa fa-circle mr-2"
                                style="font-size:10px; color:#4aa2ee;"></i>You can select ingredients to exclude from
                            your meal plan</span>
                    </div>


                    <div class="col-12">

                        <select id="select02" data-toggle="select" multiple
                            class="form-control form-control-lg myplan-select">
                            <!-- <option selected="" disabled="">Select any exclude</option> -->
                            <option selected="">Beans</option>
                            <option>Chicken</option>
                            <option selected="">Eggplant</option>

                            <option>Mushroom</option>
                            <option>Quinoa</option>
                            <option>Red Meat</option>
                            <option>Seafood</option>

                            <option>Nuts</option>
                            <option>Turkey</option>
                            <option>Rice</option>
                            <option>Eggs</option>

                            <option>Sesame</option>
                            <option>Soy</option>
                            <option>Chia</option>
                            <option>Cilantro</option>
                        </select>
                    </div>


                </div>


            </div>

            <div class="modal-footer">

                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save</button>

            </div>
        </div>
    </div>
</div>
<!-- end exclude modal -->

@endsection