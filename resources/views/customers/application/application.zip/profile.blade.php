@extends('layouts.customer')



<!-- maps -->
<script type="text/javascript"
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBR2HIEq1bixHiWwg4t4AyQvElMzApekCQ"></script>
<script src="https://unpkg.com/location-picker/dist/location-picker.min.js"></script>

<style type="text/css">
    #map {
        width: 100%;
        height: 480px;
        border: 5px solid white;
        border-radius: 5px;
    }
</style>
<!-- end map -->







{{-- contents --}}
@section('content')


<div class="mdk-drawer-layout js-mdk-drawer-layout" data-push data-responsive-width="992px">
    <div class="mdk-drawer-layout__content page-content">

        <!-- Header -->

        <div class="container-fluid bg-white py-3"
            style="box-shadow:0px 0px 3px 0px lightgrey; position:fixed; z-index: 1000; bottom:0px; max-width: 100%;">

            <div class="row m-navbar-row">

                <!-- Navbar button -->
                <div class="col">
                    <a href="{{ route('customer.home') }}" class="btn btn-outline-primary w-100"><i class="fa fa-home"></i></a>
                </div>

                <!-- Navbar button -->
                <div class="col">
                    <a href="{{ route('customer.chat') }}" class="btn btn-outline-primary w-100"><i class="fa fa-comment-dots"></i></a>
                </div>

                <!-- Navbar button -->
                <div class="col">
                    <a href="{{ route('customer.store') }}" class="btn btn-outline-primary w-100"><i class="fa fa-store-alt"></i></a>
                </div>

                <!-- Navbar button -->
                <!-- <div class="col-2">
                        <a href="ad.html" class="btn btn-outline-primary w-100"><i class="fa fa-ad"></i></a>
                    </div> -->


                <!-- Navbar button -->
                <div class="col">
                    <a href="{{ route('customer.plan') }}" class="btn btn-outline-primary w-100"><i class="fa fa-calendar-alt"></i></a>
                </div>

                <!-- Navbar button -->
                <div class="col">
                    <a href="{{ route('customer.profile') }}" class="btn btn-primary w-100"><i class="fa fa-user"></i></a>
                </div>


            </div>
            {{-- end menu --}}









        </div>
        <!-- // END Header -->


        <!-- breadcrubms -->
        <div class="border-bottom-2 mt-3 position-relative z-1 mb-5">
            <div class="container-fluid">

                <div class="row align-items-center general-info-row align-items-center" style="margin-top:0px;">


                    <div class="col-12 text-center mb-1">
                        <img src="{{ asset('assets/customer/images/logo/RESTAURANT.png') }}" alt=""
                            style="width:100%; height:60px; object-fit: contain;">
                    </div>



                    <!-- general info -->
                    <div class="col-6 mt-3 mb-3">
                        <h6 class="mb-0 font-size-16">Personal Info</h6>
                    </div>

                    <div class="col-6 mt-4 text-right mb-3">
                        <a href="{{ route('customer.profileEdit') }}" class="btn btn-secondary py-1"><i
                                class="fa fa-edit text-white"></i></a>
                    </div>


                    <div class="col-12">

                        <div class="row bg-white py-4" style="border-radius:5px; box-shadow:0px 0px 3px 0px lightgrey">
                            <div class="col-6">
                                <h6 class="border-right-1"><i class="fa fa-user mr-2"></i>Idress Abdulrahman</h6>
                            </div>

                            <div class="col-6">
                                <h6><i class="fa fa-phone mr-2"></i>+971 55 232 328</h6>
                            </div>


                            <div class="col-6 mt-1">
                                <h6 class="border-right-1 mb-0"><i class="fa fa-dot-circle mr-2"></i>City: Sharjah</h6>
                            </div>

                            <div class="col-6 mt-1">
                                <h6 class="mb-0"><i class="fa fa-dot-circle mr-2"></i>District: Al Abar</h6>
                            </div>


                        </div>

                    </div>
                    <!-- end general info -->




                    <!-- map info -->
                    <div class="col-12 mt-4 mb-3">
                        <h6 class="mb-0 font-size-16">Location Info</h6>
                    </div>




                    <div class="col-12">


                        <div class="row">

                            <!-- map -->
                            <div class="col-12">
                                <div id="map"></div>
                            </div>



                            <!-- buttons -->
                            <div class="col-12 text-center mt-3">
                                <button id="currentLoc" class="btn btn-outline-primary py-1 mr-1"><i
                                        class="fa fa-map-marked mr-2"></i>Currnet Location</button>
                                <button id="confirmPosition" class="btn btn-success py-1">Save Position</button>

                                <!-- hidden marks -->
                                <p class="d-none"><span id="onIdlePositionView"></span></p>
                            </div>

                        </div>

                    </div>
                </div>


                <div class="col-12">
                    <hr>
                </div>






                <!-- Subscribtion info -->
                <div class="col-12 mt-4 mb-3">
                    <h6 class="mb-0 font-size-16">Subscription Info</h6>
                </div>



                <div class="col-12 mb-5">

                    <div class="row bg-white py-4 align-items-center"
                        style="border-radius:5px; box-shadow:0px 0px 3px 0px lightgrey">
                        <div class="col-6 border-right-1 text-center">
                            <h6 class="mb-1"><i class="fa fa-calendar-alt mr-2"></i>1 Sep 2021</h6>
                            <p class="text-center mb-0">
                                <span class="badge-pill badge-secondary px-3 font-size-12 font-weight-500">Start
                                    Date</span>
                            </p>
                        </div>

                        <div class="col-6 border-right-1 text-center">
                            <h6 class="mb-1"><i class="fa fa-calendar-alt mr-2"></i>30 Sep 2021</h6>
                            <p class="text-center mb-0">
                                <span class="badge-pill badge-secondary px-3 font-size-12 font-weight-500">End
                                    Date</span>
                            </p>
                        </div>





                        <div class="col-6 border-right-1 text-center mt-3">
                            <button class="btn btn-outline-primary w-100 py-1" data-toggle="modal"
                                data-target=".renew-orders">Renew</button>

                        </div>

                        <div class="col-6 border-right-1 text-center mt-3">
                            <button class="btn btn-outline-primary w-100 py-1" data-toggle="modal"
                                data-target=".freeze-orders">Freeze</button>
                        </div>

                    </div>

                </div>





            </div>
            <!-- end row -->

        </div>
    </div>
    <!-- breadcrubms end -->






</div>
<!-- // END drawer-layout__content -->




<!-- drawrer menu was here -->

<!-- drawrer menu end -->



</div>
<!-- // END drawer-layout -->



@endsection







{{-- scripts --}}
@section('scripts')


    



    <!-- package plan js (custom added) -->
    <script src="{{ asset('assets/customer/js/package-plan.js') }}"></script>


    <!-- package plan js (custom added) -->
    <script src="{{ asset('assets/customer/js/customer-mobile.js') }}"></script>


    <!-- map script -->
    
    <script>
        // Get element references
            var confirmBtn = document.getElementById('confirmPosition');
            var onClickPositionView = document.getElementById('onClickPositionView');
            var onIdlePositionView = document.getElementById('onIdlePositionView');
    
            // Initialize locationPicker plugin
            var lp = new locationPicker('map', {
                setCurrentPosition: true, // You can omit this, defaults to true
            }, {
                zoom: 15 // You can set any google map options here, zoom defaults to 15
            });
    
            currentLoc.onclick = function () {
    
                var lp = new locationPicker('map', {
                    setCurrentPosition: true, // You can omit this, defaults to true
                }, {
                    zoom: 15 // You can set any google map options here, zoom defaults to 15
                });
    
            };
    
            // Listen to button onclick event
            confirmBtn.onclick = function () {
                // Get current location and show it in HTML and put it on inputs
                var location = lp.getMarkerPosition();
                document.getElementById('lat_input').value = location.lat;
                document.getElementById('long_input').value = location.lng;
                onClickPositionView.innerHTML = 'The chosen location is ' + location.lat + ',' + location.lng;
                onIdlePositionView.innerHTML = 'The chosen location is ' + location.lat + ',' + location.lng;
    
    
            };
    
            // Listen to map idle event, listening to idle event more accurate than listening to ondrag event
            google.maps.event.addListener(lp.map, 'idle', function (event) {
                // Get current location and show it in HTML
                var location = lp.getMarkerPosition();
                onIdlePositionView.innerHTML = 'The chosen location is ' + location.lat + ',' + location.lng;
    
            });
    
    </script>
    
    <!-- end map script -->


@endsection







{{-- modals --}}
@section('modals')

<!-- freeze modal -->
<div class="modal fade freeze-orders" data-backdrop="false" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-sm" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel" style="letter-spacing: 0.4px !important;">Freeze Orders
                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body">

                <div class="row">

                    <div class="col-6 mb-3">
                        <label for="" class="mb-1">From</label>
                        <input type="date" name="" id="" class="form-control">
                    </div>

                    <div class="col-6 mb-3">
                        <label for="" class="mb-1">Until</label>
                        <input type="date" name="" id="" class="form-control">
                    </div>


                </div>


            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary py-1" data-dismiss="modal">Close</button>

                <button type="button" class="btn btn-primary py-1" data-dismiss="modal">Confirm</button>

            </div>
        </div>
    </div>
</div>
<!-- end freeze modal -->








<!-- renew modal -->
<div class="modal fade renew-orders" data-backdrop="false" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-sm" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel" style="letter-spacing: 0.4px !important;">Renew Orders
                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body">

                <div class="row">

                    <div class="col-6 mb-3">
                        <label for="" class="mb-1">Starts From</label>
                        <input type="date" name="" id="" class="form-control">
                    </div>

                    <div class="col-6 mb-3">
                        <label for="" class="mb-1">No. of orders</label>
                        <input type="number" name="" id="" class="form-control">
                    </div>


                </div>


            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary py-1" data-dismiss="modal">Close</button>

                <button type="button" class="btn btn-primary py-1" data-dismiss="modal">Confirm</button>

            </div>
        </div>
    </div>
</div>
<!-- end renew modal -->


@endsection