@extends('layouts.customer')




{{-- contents --}}
@section('content')

<div class="mdk-drawer-layout js-mdk-drawer-layout" data-push data-responsive-width="992px">
    <div class="mdk-drawer-layout__content page-content">

        <!-- Header -->

        <div class="container-fluid bg-white py-3"
            style="box-shadow:0px 0px 3px 0px lightgrey; position:fixed; z-index: 1000; bottom:0px; max-width: 100%;">

            <div class="row m-navbar-row">

                <!-- Navbar button -->
                <div class="col">
                    <a href="{{ route('customer.home') }}" class="btn btn-outline-primary w-100"><i class="fa fa-home"></i></a>
                </div>

                <!-- Navbar button -->
                <div class="col">
                    <a href="{{ route('customer.chat') }}" class="btn btn-outline-primary w-100"><i class="fa fa-comment-dots"></i></a>
                </div>

                <!-- Navbar button -->
                <div class="col">
                    <a href="{{ route('customer.store') }}" class="btn btn-primary w-100"><i class="fa fa-store-alt"></i></a>
                </div>

                <!-- Navbar button -->
                <!-- <div class="col-2">
                        <a href="ad.html" class="btn btn-outline-primary w-100"><i class="fa fa-ad"></i></a>
                    </div> -->


                <!-- Navbar button -->
                <div class="col">
                    <a href="{{ route('customer.plan') }}" class="btn btn-outline-primary w-100"><i class="fa fa-calendar-alt"></i></a>
                </div>

                <!-- Navbar button -->
                <div class="col">
                    <a href="{{ route('customer.profile') }}" class="btn btn-outline-primary w-100"><i class="fa fa-user"></i></a>
                </div>


            </div>
            {{-- end menu --}}









        </div>
        <!-- // END Header -->


        <!-- breadcrubms -->
        <div class="border-bottom-2 mt-3 position-relative z-1 mb-5">
            <div class="container-fluid">

                <div class="row align-items-center" style="margin-top:0px;">




                    <div class="col-12 text-center mb-1">
                        <img src="{{ asset('assets/customer/images/logo/RESTAURANT.png') }}" alt=""
                            style="width:100%; height:60px; object-fit: contain;">
                    </div>





                    <div class="col-12">

                        <!-- carousal -->
                        <div class="row align-items-center mt-3" style="position: relative;">

                            <div class="col-12 text-center mb-3">
                                <button type="button" class="btn btn-sm py-1 btn-success px-3" data-toggle="modal"
                                    data-target=".purchase-history">
                                    View Purchases
                                </button>
                            </div>


                            <!-- patch 1 -->
                            <div class="col-6 m-boxes-1">
                                <div class="m-boxes">
                                    <h6 style="margin-bottom:2px !important;">Items Selected</h6>
                                    <p class="mb-0">2</p>
                                </div>
                            </div>

                            <div class="col-6 m-boxes-1">
                                <div class="m-boxes">
                                    <h6 style="margin-bottom:2px !important;">Items Charge</h6>
                                    <p class="mb-0">100</p>
                                </div>
                            </div>




                            <div class="col-12">
                                <hr class="w-50 mb-0">
                            </div>

                        </div>
                        <!-- end carousal -->

                    </div>
                    <!-- end carousal col -->


                    <div class="col-12 text-left mt-4">
                        <h6 class="font-weight-medium font-weight-500"><i class="fa fa-info-circle mr-2"
                                style="color:#4aa2ee; font-size: 16px; text-transform: unset !important;"></i>This item
                            will be added in
                            your next delivery</h6>
                    </div>



                    <!-- meal 1 -->
                    <div class="col-12 mb-4">

                        <div class="m-meal-card">
                            <div class="row py-3 align-items-center px-2">

                                <!-- image -->
                                <div class="col-4">
                                    <img width="90" height="90" src="{{ asset('assets/customer/images/stories/greenjuice.jpg') }}"
                                        style="border-radius: 50%; object-fit: contain;">
                                </div>

                                <!-- info + quantity-->
                                <div class="col-8">

                                    <h6 class="mb-1">Green Juice</h6>
                                    <p class="mb-0 text-secondary font-size-12 font-weight-bold">
                                        <span class="text-primary mr-1">Price: 50 (AED)</span>|<span
                                            class="text-secondary ml-1">Cal: 60</span>
                                    </p>
                                    <hr class="mt-2 mb-2">
                                    <input type="number" name="" id="" class="form-control" placeholder="Quantity">

                                </div>

                            </div>
                        </div>
                    </div>
                    <!-- end card col 1-->




                    <!-- meal -->
                    <div class="col-12 mb-4">

                        <div class="m-meal-card">
                            <div class="row py-3 align-items-center px-2">

                                <!-- image -->
                                <div class="col-4">
                                    <img width="90" height="90" src="{{ asset('assets/customer/images/stories/whey-protein.webp') }}"
                                        style="border-radius: 50%; object-fit: contain;">
                                </div>

                                <!-- info + quantity-->
                                <div class="col-8">

                                    <h6 class="mb-1">Whey Protein</h6>
                                    <p class="mb-0 text-secondary font-size-12 font-weight-bold">
                                        <span class="text-primary mr-1">Price: 120 (AED)</span>|<span
                                            class="text-secondary ml-1">Cal:
                                            250</span>
                                    </p>
                                    <hr class="mt-2 mb-2">
                                    <input type="number" name="" id="" class="form-control" placeholder="Quantity">

                                </div>

                            </div>
                        </div>
                    </div>
                    <!-- end card col-->







                    <!-- meal -->
                    <div class="col-12 mb-4">

                        <div class="m-meal-card">
                            <div class="row py-3 align-items-center px-2">

                                <!-- image -->
                                <div class="col-4">
                                    <img width="90" height="90"
                                        src="{{ asset('assets/customer/images/stories/Salmon-and-Quinoa-Salad-Meal.png') }}"
                                        style="border-radius: 50%; object-fit: contain;">
                                </div>

                                <!-- info + quantity-->
                                <div class="col-8">

                                    <h6 class="mb-1">Extra Meal</h6>
                                    <p class="mb-0 text-secondary font-size-12 font-weight-bold">
                                        <span class="text-primary mr-1">Price: 37 (AED)</span>|<span
                                            class="text-secondary ml-1">Cal:
                                            400</span>
                                    </p>
                                    <hr class="mt-2 mb-2">
                                    <input type="number" name="" id="" class="form-control" placeholder="Quantity">

                                </div>

                            </div>
                        </div>
                    </div>
                    <!-- end card col-->




                    <div class="col-12 text-center mt-2 mb-5">
                        <button class="btn btn-primary px-4">Confirm Order</button>
                    </div>



                </div>
                <!-- end row -->

            </div>
        </div>
        <!-- breadcrubms end -->




    </div>
    <!-- // END drawer-layout__content -->




    <!-- drawrer menu was here -->

    <!-- drawrer menu end -->



</div>
<!-- // END drawer-layout -->


@endsection





{{-- scripts --}}
@section('scripts')


    <!-- package plan js (custom added) -->
    <script src="{{ asset('assets/customer/js/package-plan.js') }}"></script>


    <!-- package plan js (custom added) -->
    <script src="{{ asset('assets/customer/js/customer-mobile.js') }}"></script>



@endsection




{{-- modals --}}
@section('modals')


    <!-- purcahse history -->
    <div class="modal fade purchase-history" data-backdrop="false" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel" style="letter-spacing: 0.4px !important;">Purchases</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
    
                <div class="modal-body">
    
                    <div class="row">
    
                        <div class="col-12 text-center">
                            <h6 class="font-size-15 mx-auto">Today's Purchase</h6>
                        </div>
    
                        <div class="col-12">
    
    
                            <div class="table-responsive">
                                <table class="table mb-0 thead-border-top-0 table-nowrap">
                                    <thead>
                                        <th class="font-size-12">Item</th>
                                        <th class="font-size-12">Price</th>
                                        <th class="font-size-12">Quantity</th>
                                        <th class="font-size-12">Delivery Date</th>
    
                                    </thead>
    
                                    <tbody>
                                        <tr>
                                            <td class="font-size-12">Green Juice</td>
                                            <td class="font-size-12">50</td>
                                            <td class="font-size-12">2</td>
                                            <td class="font-size-12">16 Oct 2021</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
    
                        </div>
                        <!-- end col 12 -->
    
    
    
    
    
    
                        <div class="col-12 mt-4">
    
                            <hr>
    
                            <div class="col-12 text-center">
                                <h6 class="font-size-15">Purchase History</h6>
                            </div>
    
    
                            <div class="table-responsive">
                                <table class="table mb-0 thead-border-top-0 table-nowrap">
                                    <thead>
                                        <th class="font-size-12">Item</th>
                                        <th class="font-size-12">Price</th>
                                        <th class="font-size-12">Quantity</th>
                                        <th class="font-size-12">Delivery Date</th>
    
                                    </thead>
    
                                    <tbody>
                                        <tr>
                                            <td class="font-size-12">Green Juice</td>
                                            <td class="font-size-12">50</td>
                                            <td class="font-size-12">1</td>
                                            <td class="font-size-12">12 Oct 2021</td>
                                        </tr>
    
                                        <tr>
                                            <td class="font-size-12">Whey Protein</td>
                                            <td class="font-size-12">120</td>
                                            <td class="font-size-12">3</td>
                                            <td class="font-size-12">12 Oct 2021</td>
                                        </tr>
    
                                        <tr>
                                            <td class="font-size-12">Whey Protein</td>
                                            <td class="font-size-12">120</td>
                                            <td class="font-size-12">2</td>
                                            <td class="font-size-12">8 Oct 2021</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
    
                        </div>
                        <!-- end col 12 -->
    
    
                    </div>
                    <!-- end row -->
    
    
                </div>
                <!-- end modal body -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <!-- end package modal -->



@endsection