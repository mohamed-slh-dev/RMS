@extends('layouts.customer')




{{-- contents --}}
@section('content')

<div class="mdk-drawer-layout js-mdk-drawer-layout" data-push data-responsive-width="992px">
    <div class="mdk-drawer-layout__content page-content">

        <!-- Header -->

        <div class="container-fluid bg-white py-3"
            style="box-shadow:0px 0px 3px 0px lightgrey; position:fixed; z-index: 1000; bottom:0px; max-width: 100%;">

            <div class="row m-navbar-row">

                <!-- Navbar button -->
                <div class="col">
                    <a href="{{ route('customer.home') }}" class="btn btn-outline-primary w-100"><i class="fa fa-home"></i></a>
                </div>

                <!-- Navbar button -->
                <div class="col">
                    <a href="{{ route('customer.chat') }}" class="btn btn-primary w-100"><i class="fa fa-comment-dots"></i></a>
                </div>

                <!-- Navbar button -->
                <div class="col">
                    <a href="{{ route('customer.store') }}" class="btn btn-outline-primary w-100"><i class="fa fa-store-alt"></i></a>
                </div>

                <!-- Navbar button -->
                <!-- <div class="col-2">
                        <a href="ad.html" class="btn btn-outline-primary w-100"><i class="fa fa-ad"></i></a>
                    </div> -->


                <!-- Navbar button -->
                <div class="col">
                    <a href="{{ route('customer.plan') }}" class="btn btn-outline-primary w-100"><i class="fa fa-calendar-alt"></i></a>
                </div>

                <!-- Navbar button -->
                <div class="col">
                    <a href="{{ route('customer.profile') }}" class="btn btn-outline-primary w-100"><i class="fa fa-user"></i></a>
                </div>


            </div>
            {{-- end menu --}}









        </div>
        <!-- // END Header -->


        <!-- breadcrubms -->
        <div class="border-bottom-2 mt-3 position-relative z-1 mb-5">
            <div class="container-fluid">

                <div class="row align-items-center general-info-row align-items-center" style="margin-top:0px;">


                    <div class="col-12 px-0"
                        style="position: relative; background-image: url({{ asset('assets/customer/images/logo/RESTAURANT.png') }}); background-size: contain; background-position: top; height: 200px; border-top-left-radius: 5px; border-top-right-radius: 5px; background-repeat: no-repeat;">

                        <!-- overlay -->
                        <div class="hero-overlay"
                            style="position: absolute; top:0px; left: 0px; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.404); border-top-left-radius: 5px; border-top-right-radius: 5px;">
                        </div>

                        <div class="row align-items-center h-100">
                            <div class="col-6 text-right">
                                <button class="btn btn-success px-4 py-1 font-weight-bold"
                                    style="box-shadow: 0px 0px 2px 0px rgb(0, 190, 0);">
                                    <i class="fa fa-phone-alt mr-2"></i>Call
                                </button>
                            </div>

                            <div class="col-6 text-left">
                                <a href="{{ route('customer.chatRoom') }}" class="btn btn-success px-4 py-1 font-weight-bold"
                                    style="box-shadow: 0px 0px 2px 0px rgb(0, 190, 0);">
                                    <i class="fa fa-comment-dots mr-2 text-white"></i>Chat
                                </a>
                            </div>


                        </div>
                    </div>



                    <div class="col-12">

                        <div class="row bg-white py-3" style="border-radius:5px; box-shadow:0px 0px 3px 0px lightgrey">
                            <div class="col-12 text-center">
                                <h6 class="border-right-1 border-left-1 mb-0"><i class="fa fa-info-circle mr-2"></i> {{ $customer->deliveries->count() }} Deliveries</h6>
                            </div>


                        </div>

                    </div>
                    <!-- end general info -->




                    <div class="col-12">
                        <hr>
                    </div>





                    <!-- Subscribtion info -->
                    <div class="col-12 mt-3 mb-3">
                        <h6 class="mb-0 font-size-16">Subscription Info</h6>
                    </div>



                    <div class="col-12">

                        <div class="row bg-white py-4 align-items-center"
                            style="border-radius:5px; box-shadow:0px 0px 3px 0px lightgrey">
                            <div class="col-6 border-right-1 text-center">
                                <h6 class="mb-1"><i class="fa fa-calendar-alt mr-2"></i>{{ date('d M Y', strtotime($customer->from_date)) }}</h6>
                                <p class="text-center mb-0">
                                    <span class="badge-pill badge-secondary px-3 font-size-12 font-weight-500">Start
                                        Date</span>
                                </p>
                            </div>

                            <div class="col-6 border-right-1 text-center">
                                <h6 class="mb-1"><i class="fa fa-calendar-alt mr-2"></i>{{ date('d M Y', strtotime($customer->to_date)) }}</h6>
                                <p class="text-center mb-0">
                                    <span class="badge-pill badge-secondary px-3 font-size-12 font-weight-500">End
                                        Date</span>
                                </p>
                            </div>





                            <div class="col-6 border-right-1 text-center mt-3">
                                <button class="btn btn-outline-primary w-100 py-1" data-toggle="modal"
                                    data-target=".renew-orders">Renew</button>

                            </div>

                            <div class="col-6 border-right-1 text-center mt-3">
                                <button class="btn btn-outline-primary w-100 py-1" data-toggle="modal"
                                    data-target=".freeze-orders">Freeze</button>
                            </div>

                        </div>

                    </div>





                </div>
                <!-- end row -->

            </div>
        </div>
        <!-- breadcrubms end -->




    </div>
    <!-- // END drawer-layout__content -->




    <!-- drawrer menu was here -->

    <!-- drawrer menu end -->



</div>
<!-- // END drawer-layout -->



@endsection






{{-- sections --}}
@section('sections')

<!-- package plan js (custom added) -->
<script src="{{ asset('assets/customer/js/package-plan.js') }}"></script>


<!-- package plan js (custom added) -->
<script src="{{ asset('assets/customer/js/customer-mobile.js') }}"></script>


@endsection








{{-- modals --}}
@section('modals')

<!-- freeze modal -->
<div class="modal fade freeze-orders" data-backdrop="false" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-sm" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel" style="letter-spacing: 0.4px !important;">Freeze Orders
                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body">

                <div class="row">

                    <div class="col-6 mb-3">
                        <label for="" class="mb-1">From</label>
                        <input type="date" name="" id="" class="form-control">
                    </div>

                    <div class="col-6 mb-3">
                        <label for="" class="mb-1">Until</label>
                        <input type="date" name="" id="" class="form-control">
                    </div>


                </div>


            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary py-1" data-dismiss="modal">Close</button>

                <button type="button" class="btn btn-primary py-1" data-dismiss="modal">Confirm</button>

            </div>
        </div>
    </div>
</div>
<!-- end freeze modal -->








<!-- renew modal -->
<div class="modal fade renew-orders" data-backdrop="false" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-sm" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel" style="letter-spacing: 0.4px !important;">Renew Orders
                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body">

                <div class="row">

                    <div class="col-6 mb-3">
                        <label for="" class="mb-1">Starts From</label>
                        <input type="date" name="" id="" class="form-control">
                    </div>

                    <div class="col-6 mb-3">
                        <label for="" class="mb-1">No. of orders</label>
                        <input type="number" name="" id="" class="form-control">
                    </div>


                </div>


            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary py-1" data-dismiss="modal">Close</button>

                <button type="button" class="btn btn-primary py-1" data-dismiss="modal">Confirm</button>

            </div>
        </div>
    </div>
</div>
<!-- end renew modal -->

@endsection




